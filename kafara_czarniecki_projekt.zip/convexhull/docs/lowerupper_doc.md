# Górna-dolna

## Jak działa? 

Algorytm jest prosty: 

1. Sortujemy punkty po odciętych (współrzędne x) (przyjmijmy, że sortujemy rosnąco)
   1. W przypadku gdy istnieje więcej niż jeden punkt o tej samej odciętej, przyjmujemy, że mniejszy jest ten o mniejszej rzędnej.
2. 